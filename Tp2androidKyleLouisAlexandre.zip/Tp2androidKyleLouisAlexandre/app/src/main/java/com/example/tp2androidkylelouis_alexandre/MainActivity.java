package com.example.tp2androidkylelouis_alexandre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.util.Random;
import java.util.Scanner;


enum Genre {
    Homme, Femme, Elf
};

class Perssonnage {
    int sante;
    int Force;
    String Nom;

    public Perssonnage(int Vie, int force, String nom) {
        sante = Vie;
        Force = force;
        Nom = nom;
    }

    public int DifficultyChoose() {//Choisi le niveau de difficulter (Stats de l'ennemi et Hero)
        Scanner lire = new Scanner(System.in);
        System.out.println("Choisisser la difficulte de " + this.Nom);
        System.out.println("1-Facile  2-Dure ");
        System.out.println("1-Facile == Force= 40 et vie = 30  2-Dure== Force 10 et vie 5 ");
        int num = lire.nextInt();

        if (num <1 && num > 2)
        {
            DifficultyChoose();
        }
        return num;

    }

    public boolean attaquer() {//Random de chance pour attaque reussi ou non

        Random rn = new Random();
        int maximum = 0;
        int minimum = 0;
        int n = maximum - minimum + 1;
        int i = rn.nextInt() % n;
        n = minimum + i;
        int randomNum = minimum + (int) (Math.random() * maximum);
        if (randomNum % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

}

class Hero extends Perssonnage {
    String nom;

    public Hero(int Vie, int Force, String Nom) {
        super(Vie, Force, Nom);

        nom = Nom;

    }

    public void Power(Enemi enemi) {// Selection de force qui verifie aussi le nombre de force pour vois si il est manquer ou non
        Scanner lire = new Scanner(System.in);
        System.out.println("Attaquez avec force 1, 2 ou 3?");
        int num = lire.nextInt();
        verifierattaque(num);
        if (attaquer()) {
            System.out.println("Attaque reussi! ");
            this.Force -= num;
            enemi.sante -= num;

        } else {
            System.out.println("Attaque manquer!");
        }
    }

    public void verifierattaque(int num) {
        if (num > 3) {
            System.out.println("Veuiller attaquer avec moins de froce , Attaquez avec force 1, 2 ou 3. Force restant : "
                    + this.Force);

        } else if (num < 1) {
            System.out.println("Veuiller attaquer avec plus de froce , Attaquez avec force 1, 2 ou 3. Force restant : "
                    + this.Force);

        }

    }

    public void Difficulty() {// set les stats
        int num = this.DifficultyChoose();

        if (num == 1) {
            this.Force = 40;
            this.sante = 30;
        } else {
            this.Force = 20;
            this.sante = 5;
        }
    }

}

class Enemi extends Perssonnage  {
    String Race;

    public Enemi(int Vie, int Force, String Nom) {
        super(Vie, Force, Nom);
        Race = Nom;
    }

    public boolean attaquer() {

        Random rn = new Random();
        int maximum = 0;
        int minimum = 0;
        int n = maximum - minimum + 1;
        int i = rn.nextInt() % n;
        n = minimum + i;
        int randomNum = minimum + (int) (Math.random() * maximum);
        if (randomNum % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

    public void Difficulty() {
        int num = this.DifficultyChoose();

        if (num == 1) {
            this.sante = 30;
            this.Force = 40;

        } else {
            this.sante = 5;
            this.Force = 15;
        }
    }

    public void attaquerJoueur(Hero hero) {//Fait un random qui choisi de 1 a 3 pour attaquer le joueur
        if (attaquer()) {
            int max = 3;
            int min = 1;

            Random randomNum = new Random();
            int degat = min + randomNum.nextInt(max);
            System.out.println("Ennemi attaque reussi! Vous perdez -" + degat);
            hero.sante -= degat;
        } else {
            System.out.println("Ennemi attaque manquer!");
        }
    }




    public static boolean conditionVictoire(Hero hero, Enemi enemi) {//Je verefie la condition de victoire si l'hero n'a plus de force ou de vie qui renvoie un bool au while
        if (hero.sante <= 0 || hero.Force <= 0) {
            System.out.println("DEFAITE");
            return false;
        } else if (enemi.sante <= 0) {
            System.out.println("VICTOIRE");
            return false;
        }
        return true;
    }

    public static String GenrePrecis(int num) {//Ici un switch pour la selection de le genre du Hero
        String legenre;

        switch (num) {
            case 1:
                return Genre.Homme.name();
            case 2:
                return Genre.Femme.name();
            case 3:
                return Genre.Elf.name();

            default:
                return "Autre";

        }
    }



    public static void Stats(Hero hero, Enemi enemi) {//Une fonction que j'appel a la fin de chaque tour du jeu pour donner a l'usager les stats!
        System.out.println(hero.nom + " Force : " + hero.Force + " Vie : " + hero.sante + "  Ennemi :" + enemi.Race
                + " Sante: " + enemi.sante);
    }
    public static void Menu()
    {
        Scanner lire = new Scanner(System.in);
        Scanner liregenre = new Scanner(System.in);
        Scanner lireRace = new Scanner(System.in);
        System.out.println("BIENVENUE AU JEU HERO ET MECHANTS");
        System.out.println("Hero! Tapez votre nom!");
        String nom = lire.nextLine();
        System.out.println("Choisisser votre genre 1:Homme 2:Femme 3:Elf");
        int genre = liregenre.nextInt();
        String genreprecis = GenrePrecis(genre);
        System.out.println(genreprecis + " " + nom + " Taper la race de l'ennemi : ");
        String race = lireRace.nextLine();

        Hero hero = new Hero(10, 10, nom);
        Enemi enemi = new Enemi(10, 10, race);
        Boolean condition = true;
        System.out.println("Debut du jeu! ");

        enemi.Difficulty();

        hero.Difficulty();
        while (condition ) {
            Stats(hero, enemi);

            hero.Power(enemi);
            enemi.attaquerJoueur(hero);

            condition = conditionVictoire(hero, enemi);
        }
    }
    public static boolean jouer()
    {
        Scanner lirekey = new Scanner(System.in);
        System.out.println("Voulez vous rejouer? Si oui peser le 1 sinon autre option quittera!");

        int key = lirekey.nextInt();
        if(key==1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//Bouton pour aller sur jouer
        Button btnAllerAutreActivite = findViewById(R.id.Jouerbtn);
        btnAllerAutreActivite.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Bataille.class);
            intent.putExtra("msg", "LA BATAILLE ULTIME!");
            startActivity(intent);
        });
        //Bouton pour quitter
        Button btnFinirActivite = findViewById(R.id.Quitterbtn);
        btnFinirActivite.setOnClickListener(view -> {
            this.finishAffinity();
        });
    }
}